#define QT_FEATURE_quick_draganddrop 1

