#define QT_FEATURE_qml_network 1

#define QT_FEATURE_qml_debug 1

